import { Component, Input, OnInit, ViewChild, ɵCompiler_compileModuleSync__POST_R3__ } from '@angular/core';
import { Router } from '@angular/router';
import { of } from 'rxjs';
import { CountdownComponent } from 'ngx-countdown';
import * as $ from 'jquery';
import { Options } from 'ng5-slider';
import { ApiService } from '../../services/api.service';
import Swal from 'sweetalert2';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-question-page',
  templateUrl: './question-page.component.html',
  styleUrls: ['./question-page.component.css']
})
export class QuestionComponent implements OnInit {

  status = '';
  currentIndex = 0;
  questionData: any = {};
  userLogin = false;
  withoutPin = true;
  rating = 0;
  pinID: any;
  questionObj: any = {};
  flagCompleted = false;
  @ViewChild('countdown') counter: CountdownComponent;
  private readonly MAX_NUMBER_OF_STARS = 5;
  timer: any;
  questionList: any;
  percentageValue: any = {};
  @ViewChild('cd', { static: false }) private countdown: QuestionComponent;
  value: number = 0;
  options: Options = {
    floor: -50,
    ceil: 50,
    step: 0.1
  };
  answersRating: any = [];
  constructor(private router: Router,
              private apiService: ApiService,
              private cookieService: CookieService) {

  }

  ngOnInit() {
    console.log('this.currentIndex', this.currentIndex);
    try {
      if (this.cookieService.get('happily_user')) {
        this.pinID = JSON.parse(this.cookieService.get('happily_user')).pinCode;
        this.userLogin = true;
      } else {
        this.pinID = JSON.parse(this.cookieService.get('withOutLoginPin')).pinCode;
        this.withoutPin = false;
      }
    } catch (error) {
      console.log(error);
    }
    $('.ng5-slider-floor').css('display', 'none');
    $('.ng5-slider-ceil').css('display', 'none');
    $('.ng5-slider-model-value').css('display', 'none');
    this.questionListData();
  }

  public finishTest(event: any) {
    // if (event.action == 'done') {
    // console.log('countdownEvent', event);
    // this.router.navigateByUrl('/');
    // }
  }
  // public start() {
  //   this.countdown.begin();
  // }

  getVal(evt: any) {
    this.rating = evt;
    console.log('evt', this.rating);
  }

  async getPreviousQuestionPair(value: any, selectedQuestionIndex: number) {
   console.log("selectedQuestionIndex", selectedQuestionIndex)
    // tslint:disable-next-line:prefer-for-of
   for (const iterator of this.answersRating) {
     const rating = iterator.rating;
     console.log('rrrrrrrrrrr', rating);
     
     if ((selectedQuestionIndex - 1 ) === iterator.qIndex) {
       this.value = rating;
     }
   }

  // // tslint:disable-next-line:align
  // if (this.answersRating.findIndex(y => y.questionId === value.id)) {
  //   // tslint:disable-next-line:prefer-for-of
  //   for (let i = 0; i < this.answersRating.length; i++) {
  //    const element = this.answersRating[i].questionId;
  //    console.log('element', element);
  //    this.answersRating.splice(value.id, 1);
  //  }
  //   // this.answersRating.push({ questionId: value.id, rating: this.rating, pinCode: this.pinID });
  // }

  //  console.log('<<<<<<<<', this.value);
  //   console.log('this.currentIndex', this.currentIndex);
  //   console.log('currentValue', this.value);

   this.currentIndex--;
  //   this.answersRating.forEach(element => {
  //   this.value.push(element.rating);
  //   console.log('last', this.value);
  //  });
    // try {
    //     const setQuestionData = await this.apiService.post('question/', this.questionData.id);
    //     if (setQuestionData.statusMessage && setQuestionData.statusMessage === 'Success') {
    //       Swal.fire({
    //         position: 'center',
    //         icon: 'success',
    //         title: 'Question Submit Successfully!',
    //         showConfirmButton: false,
    //         timer: 1000
    //       });
    //     }
    //   } catch (error) {
    //     console.log(error.error);
    //   }
  }

  async getNextQuestionPair(value: any, selectedQuestionIndex: number) {
    console.log('selectedQuestionIndex', selectedQuestionIndex);
    console.log('this.value', this.value);
    
    let message = '';
    if (this.pinID && (this.userLogin === true)) {
      console.log('login');
      // item.user_id = this.UserID;if()
      this.answersRating.push({ questionId: value.id, qIndex: selectedQuestionIndex, rating: this.rating, pinCode: this.pinID });

      this.currentIndex++;
      this.value = 0;
      console.log('this.currentIndex', this.currentIndex);
      console.log('this.answersRating.length', this.answersRating.length);
      console.log('this.answersRating', this.answersRating);
      if (this.answersRating.length === 16) {
          try {
            // tslint:disable-next-line:max-line-length
            const data = await this.apiService.post('answers-rating', { answersRating: this.answersRating });
            this.questionObj = data.results;
            console.log('OBG', this.questionObj);
            message = data.statusMessage;
            const userAnswerData = this.questionObj[0];
            this.cookieService.set('user_pin', JSON.stringify(userAnswerData));
            if (data.statusMessage && data.statusMessage === 'Success') {
              Swal.fire({
                position: 'center',
                icon: 'success',
                title: 'Your Self-Reflection Test',
                text: 'Congratulations!  You have successfully completed your self-reflection test!',
                showConfirmButton: false,
                timer: 2000
              });
            }
            this.router.navigateByUrl('/show-result');
          } catch (error) {
            console.log(error.error);
          }
        }
        // tslint:disable-next-line:align
      } else if (this.pinID && (this.withoutPin === false && this.userLogin === false)) {
        console.log('with');
        this.answersRating.push({ questionId: value.id, rating: this.rating, pinCode: this.pinID });
        if (this.answersRating.findIndex(y => y.questionId === value.id)) {
          // tslint:disable-next-line:prefer-for-of
          for (let i = 0; i < this.answersRating.length; i++) {
           const element = this.answersRating[i].questionId;
           console.log('element', element);
           this.answersRating.splice(value.id, 1);
         }
        }
        this.currentIndex++;
        if (this.answersRating.length === 16) {
          try {
            // tslint:disable-next-line:max-line-length
            const data = await this.apiService.post('answers-rating', { answersRating: this.answersRating });
            this.questionObj = data.results;
            const userAnswerData = this.questionObj[0];
            message = data.statusMessage;
            this.cookieService.set('user_pin', JSON.stringify(userAnswerData));
            if (this.questionObj.length === 16) {
              this.flagCompleted = true;
            }
            if (data.statusMessage && data.statusMessage === 'Success') {
              Swal.fire({
                position: 'center',
                icon: 'success',
                title: 'Your Self-Reflection Test',
                text: 'Congratulations!  You have successfully completed your self-reflection test!',
                showConfirmButton: false,
                timer: 2000
              });
            }
          } catch (error) {
            console.log(error.error);
          }
          this.flagCompleted = true;
        }
      } else {
        console.log('without');
        this.answersRating.push({ questionId: value.id, rating: this.rating });
        if (this.answersRating.findIndex(y => y.questionId === value.id)) {
          // tslint:disable-next-line:prefer-for-of
          for (let i = 0; i < this.answersRating.length; i++) {
           const element = this.answersRating[i].questionId;
           console.log('element', element);
           this.answersRating.splice(value.id, 1);
         }
        }
        this.currentIndex++;
        if (this.answersRating.length === 16) {
          try {
            // tslint:disable-next-line:max-line-length
            const data = await this.apiService.post('answers-rating', { answersRating: this.answersRating });
            this.questionObj = data.results;
            const userAnswerData = this.questionObj[0];
            message = data.statusMessage;
            this.cookieService.set('user_pin', JSON.stringify(userAnswerData));
            if (this.questionObj.length === 16) {
              this.flagCompleted = true;
            }
            if (data.statusMessage && data.statusMessage === 'Success') {
              Swal.fire({
                position: 'center',
                icon: 'success',
                title: 'Your Self-Reflection Test',
                text: 'Congratulations!  You have successfully completed your self-reflection test!',
                showConfirmButton: false,
                timer: 2000
              });
            }
          } catch (error) {
            console.log(error.error);
          }
          this.flagCompleted = true;
        }
      }
  }

  async questionListData() {
    try {
      const getQuestionData = await this.apiService.get('question/get-all-questions');
      if (getQuestionData.statusMessage && getQuestionData.statusMessage === 'Success') {
        this.questionList = getQuestionData.results;
      }
    } catch (error) {
      console.log(error.error);
    }
  }

}
